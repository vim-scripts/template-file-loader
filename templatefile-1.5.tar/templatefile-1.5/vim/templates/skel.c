/*
 * $Id$
 */

#include <stdio.h>
#include "@FILE@.h"

/* Function int main(int argc, char **argv) {{{ */
int main(int argc, char **argv)
{


	return 0;
} /* }}} */


/* Modeline for ViM {{{
 * vim:set ts=4:
 * vim600:fdm=marker fdl=0 fdc=3:
 * }}} */

